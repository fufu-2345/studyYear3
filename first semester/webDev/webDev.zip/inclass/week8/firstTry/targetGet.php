<html>
    <body>
        <?php
        $country = $_GET["country"];
        $language = $_GET["lang"];
    ?>
    country: <?=$country?><br/>
    lang: <?=$language?>
    </body>

</html>