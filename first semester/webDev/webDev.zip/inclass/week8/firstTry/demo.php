<html>
    <body>
        <?php
        $m="hello<br/>";
        $a="aaa";
        $b="bbb";
    ?>
    name: <?=$m?>
    </body>

</html>