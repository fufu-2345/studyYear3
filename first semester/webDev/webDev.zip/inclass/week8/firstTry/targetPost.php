<html>
    <body>
        <?php
        $country = $_POST["country"];
        $language = $_POST["lang"];
    ?>
    country: <?=$country?><br/>
    lang: <?=$language?>
    </body>

</html>