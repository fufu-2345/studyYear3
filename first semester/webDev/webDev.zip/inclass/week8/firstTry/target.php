<html>
    <body>
        <?php
        $m="hello<br/>";
        $a="aaa";
        $b="bbb";
        $country = $_GET["country"];
        $language = $_GET["lang"];
    ?>
    name: <?=$m?>
    country: <?=$country?><br/>
    lang: <?=$language?>
    </body>

</html>