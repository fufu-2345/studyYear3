<html>
    <body>
       <form action="targetGet.php" method="get">
            Country:<input type="text" name="country"><br/>
            Language:<input type="text" name="lang"><br/>
            <input type="submit">
       </form>
    </body>

</html>