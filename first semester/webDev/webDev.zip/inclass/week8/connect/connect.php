<?php
$pdo = new PDO("mysql:host=127.0.0.1; dbname=168DB_2; charset=utf8", "168DB2", "2be6G243");
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
?>