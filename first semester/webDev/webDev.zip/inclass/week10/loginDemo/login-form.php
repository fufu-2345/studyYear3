<html>
<body>
<form action="check-login.php" method="POST">
    Username: <input type="text" name="username"><br>
    Password: <input type="password" name="password"><br>
    <input type="submit" value="Login">
</form><br/><br/>
สมมุติให้ somsak เป็น admin
</body>
</html>